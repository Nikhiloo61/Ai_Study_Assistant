// server.js — Main entry point for AI Study Assistant
// =====================================================
// Load environment variables from .env file FIRST
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const flash = require('connect-flash');
const methodOverride = require('method-override');
const path = require('path');

// Import Models
const User = require('./models/User');
const Question = require('./models/Question');

// ─── APP SETUP ────────────────────────────────────────────────────────────────
const app = express();
const PORT = process.env.PORT || 3000;

// ─── TEMPLATE ENGINE ──────────────────────────────────────────────────────────
app.set('view engine', 'ejs');                      // Use EJS for templates
app.set('views', path.join(__dirname, 'views'));     // Views folder

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────────
app.use(express.urlencoded({ extended: true }));     // Parse form data
app.use(express.json());                             // Parse JSON
app.use(methodOverride('_method'));                  // Support PUT/DELETE in forms
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'fallbacksecret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // 1 day
}));

// Flash messages (success/error notifications)
app.use(flash());

// ─── GLOBAL VARIABLES MIDDLEWARE ──────────────────────────────────────────────
// Makes these variables available in ALL EJS templates
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.currentUser = req.session.userId ? req.session.user : null;
  next();
});

// ─── AUTHENTICATION MIDDLEWARE ────────────────────────────────────────────────
// Protect routes — redirects to login if not logged in
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  req.flash('error_msg', 'Please login to access this page');
  res.redirect('/login');
}

// ─── DATABASE CONNECTION ──────────────────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('✅ MongoDB Connected Successfully');
    // Seed sample questions if the collection is empty
    await seedQuestions();
  })
  .catch(err => {
    console.error('❌ MongoDB Connection Error:', err.message);
    process.exit(1);
  });

// ─── SEED FUNCTION ────────────────────────────────────────────────────────────
// Adds sample quiz questions to the database on first run
async function seedQuestions() {
  const count = await Question.countDocuments();
  if (count > 0) return; // Don't seed if questions already exist

  const sampleQuestions = [
    {
      questionText: 'What does CPU stand for?',
      options: ['Central Processing Unit', 'Computer Personal Unit', 'Central Program Utility', 'Core Processing Unit'],
      correctAnswerIndex: 0,
      category: 'Computer Science',
      difficulty: 'Easy',
      explanation: 'CPU stands for Central Processing Unit — the brain of a computer.'
    },
    {
      questionText: 'Which planet is known as the Red Planet?',
      options: ['Venus', 'Jupiter', 'Mars', 'Saturn'],
      correctAnswerIndex: 2,
      category: 'Science',
      difficulty: 'Easy',
      explanation: 'Mars is called the Red Planet because of iron oxide (rust) on its surface.'
    },
    {
      questionText: 'What is the time complexity of Binary Search?',
      options: ['O(n)', 'O(n²)', 'O(log n)', 'O(1)'],
      correctAnswerIndex: 2,
      category: 'Computer Science',
      difficulty: 'Medium',
      explanation: 'Binary search divides the search space in half each step, giving O(log n) complexity.'
    },
    {
      questionText: 'Who invented the World Wide Web?',
      options: ['Bill Gates', 'Tim Berners-Lee', 'Steve Jobs', 'Linus Torvalds'],
      correctAnswerIndex: 1,
      category: 'Technology',
      difficulty: 'Easy',
      explanation: 'Tim Berners-Lee invented the WWW in 1989 while working at CERN.'
    },
    {
      questionText: 'What does HTML stand for?',
      options: ['Hyper Text Markup Language', 'High Tech Modern Language', 'Hyper Transfer Markup Logic', 'Home Tool Markup Language'],
      correctAnswerIndex: 0,
      category: 'Web Development',
      difficulty: 'Easy',
      explanation: 'HTML stands for HyperText Markup Language — the standard language for web pages.'
    },
    {
      questionText: 'Which data structure uses LIFO (Last In, First Out)?',
      options: ['Queue', 'Array', 'Stack', 'Linked List'],
      correctAnswerIndex: 2,
      category: 'Computer Science',
      difficulty: 'Medium',
      explanation: 'A Stack uses LIFO — the last element added is the first one removed.'
    },
    {
      questionText: 'What is the output of 2 ** 10 in Python?',
      options: ['20', '100', '512', '1024'],
      correctAnswerIndex: 3,
      category: 'Programming',
      difficulty: 'Medium',
      explanation: '2 ** 10 means 2 raised to the power of 10, which equals 1024.'
    },
    {
      questionText: 'What does SQL stand for?',
      options: ['Simple Query Language', 'Structured Query Language', 'Standard Question Logic', 'System Query Layout'],
      correctAnswerIndex: 1,
      category: 'Database',
      difficulty: 'Easy',
      explanation: 'SQL stands for Structured Query Language, used to manage relational databases.'
    },
    {
      questionText: 'Which of these is NOT a JavaScript framework?',
      options: ['React', 'Angular', 'Django', 'Vue'],
      correctAnswerIndex: 2,
      category: 'Web Development',
      difficulty: 'Medium',
      explanation: 'Django is a Python web framework. React, Angular, and Vue are JavaScript frameworks.'
    },
    {
      questionText: 'What is the value of π (pi) approximately?',
      options: ['2.718', '3.14159', '1.618', '1.414'],
      correctAnswerIndex: 1,
      category: 'Mathematics',
      difficulty: 'Easy',
      explanation: 'Pi (π) is approximately 3.14159 — the ratio of a circle\'s circumference to its diameter.'
    }
  ];

  await Question.insertMany(sampleQuestions);
  console.log('🌱 Sample questions seeded to database!');
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.render('home', { title: 'AI Study Assistant' });
});

// ─── REGISTER ─────────────────────────────────────────────────────────────────
app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('register', { title: 'Register' });
});

app.post('/register', async (req, res) => {
  const { name, email, password, confirmPassword } = req.body;

  // Validation
  if (!name || !email || !password || !confirmPassword) {
    req.flash('error_msg', 'Please fill in all fields');
    return res.redirect('/register');
  }
  if (password !== confirmPassword) {
    req.flash('error_msg', 'Passwords do not match');
    return res.redirect('/register');
  }
  if (password.length < 6) {
    req.flash('error_msg', 'Password must be at least 6 characters');
    return res.redirect('/register');
  }

  try {
    // Check if email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      req.flash('error_msg', 'Email is already registered');
      return res.redirect('/register');
    }

    // Create new user (password is hashed automatically via pre-save hook)
    const user = await User.create({ name, email, password });

    req.flash('success_msg', '🎉 Account created! Please login.');
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Something went wrong. Please try again.');
    res.redirect('/register');
  }
});

// ─── LOGIN ────────────────────────────────────────────────────────────────────
app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.render('login', { title: 'Login' });
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    req.flash('error_msg', 'Please enter email and password');
    return res.redirect('/login');
  }

  try {
    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      req.flash('error_msg', 'Invalid email or password');
      return res.redirect('/login');
    }

    // Compare passwords
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      req.flash('error_msg', 'Invalid email or password');
      return res.redirect('/login');
    }

    // Save user info to session
    req.session.userId = user._id;
    req.session.user = { name: user.name, email: user.email, id: user._id };

    req.flash('success_msg', `Welcome back, ${user.name}! 👋`);
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Login failed. Please try again.');
    res.redirect('/login');
  }
});

// ─── LOGOUT ───────────────────────────────────────────────────────────────────
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
app.get('/dashboard', isAuthenticated, async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);
    const totalQuizzes = user.quizScores.length;
    const bestScore = user.getBestScore();
    const avgScore = user.getAvgScore();
    const totalQuestions = await Question.countDocuments();

    res.render('dashboard', {
      title: 'Dashboard',
      user,
      totalQuizzes,
      bestScore,
      avgScore,
      totalQuestions
    });
  } catch (err) {
    console.error(err);
    res.redirect('/login');
  }
});

// ─── CHATBOT ──────────────────────────────────────────────────────────────────
app.get('/chatbot', isAuthenticated, (req, res) => {
  res.render('chatbot', { title: 'AI Chatbot' });
});

// Chatbot message processing endpoint
app.post('/chatbot/message', isAuthenticated, async (req, res) => {
  const { message } = req.body;
  
  try {
    // Send the user's message to the local Ollama API
    const response = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3', // Ensure 'llama3' is pulled locally: ollama run llama3
        prompt: message,
        stream: false
      })
    });

    if (!response.ok) {
      throw new Error(`Ollama API returned status ${response.status}`);
    }

    const data = await response.json();
    res.json({ response: data.response, timestamp: new Date().toLocaleTimeString() });
  } catch (error) {
    console.error('Chatbot error:', error);
    res.json({ 
      response: "⚠️ I couldn't connect to the local AI model. Please make sure Ollama is running locally (`ollama run llama3`) to process messages.", 
      timestamp: new Date().toLocaleTimeString() 
    });
  }
});

// ─── QUIZ ─────────────────────────────────────────────────────────────────────
app.get('/quiz', isAuthenticated, async (req, res) => {
  try {
    // Fetch 10 random questions from database
    const questions = await Question.aggregate([{ $sample: { size: 10 } }]);
    res.render('quiz', { title: 'Quiz', questions });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Could not load quiz questions');
    res.redirect('/dashboard');
  }
});

// Process quiz submission
app.post('/quiz/submit', isAuthenticated, async (req, res) => {
  try {
    const { answers } = req.body; // Object: { questionId: selectedIndex }

    if (!answers || typeof answers !== 'object') {
      req.flash('error_msg', 'Invalid quiz submission');
      return res.redirect('/quiz');
    }

    const questionIds = Object.keys(answers);
    const questions = await Question.find({ _id: { $in: questionIds } });

    let score = 0;
    const results = questions.map(q => {
      const selected = parseInt(answers[q._id.toString()]);
      const isCorrect = selected === q.correctAnswerIndex;
      if (isCorrect) score++;
      return {
        questionText: q.questionText,
        options: q.options,
        correctAnswerIndex: q.correctAnswerIndex,
        selectedIndex: selected,
        isCorrect,
        explanation: q.explanation
      };
    });

    const total = questions.length;
    const percentage = Math.round((score / total) * 100);

    // Save score to user's record
    await User.findByIdAndUpdate(req.session.userId, {
      $push: {
        quizScores: { score, total, percentage }
      }
    });

    res.render('quiz-result', {
      title: 'Quiz Results',
      score,
      total,
      percentage,
      results
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Error processing quiz');
    res.redirect('/quiz');
  }
});

// ─── PROGRESS ─────────────────────────────────────────────────────────────────
app.get('/progress', isAuthenticated, async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);
    const scores = user.quizScores.sort((a, b) => new Date(b.dateTaken) - new Date(a.dateTaken));

    res.render('progress', {
      title: 'My Progress',
      user,
      scores,
      bestScore: user.getBestScore(),
      avgScore: user.getAvgScore(),
      totalQuizzes: scores.length
    });
  } catch (err) {
    console.error(err);
    res.redirect('/dashboard');
  }
});

// ─── 404 HANDLER ──────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});

// ─── START SERVER ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 AI Study Assistant is running!`);
  console.log(`📍 Visit: http://localhost:${PORT}`);
  console.log(`🔧 Press Ctrl+C to stop\n`);
});
